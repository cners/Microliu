# EDC.EasyNetQ.Demo
This is a simple demo on Message Queue &amp; Event Bus based on EasyNetQ (it is based on RabbitMQ.Client) for ASP.NET Core projects

![RabbitMQ](https://images2017.cnblogs.com/blog/668104/201709/668104-20170919144417181-47072786.png)

* EasyNetQ is the leading client API for RabbitMQ on .NET, with over 100,000 downloads on NuGet.org. It is an open source project originally sponsored by 15below the travel industry experts. 

http://easynetq.com/

* This is a simple demo based on EasyNetQ to implement one simple EventBus in ASP.NET Core projects, you can find more details on the below URL, it is one blog artcle about it.

https://www.cnblogs.com/edisonchou/p/aspnetcore_easynetq_basicdemo_foundation.html
