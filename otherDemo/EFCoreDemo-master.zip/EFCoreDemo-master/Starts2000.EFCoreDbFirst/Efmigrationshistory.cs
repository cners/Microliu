﻿using System;
using System.Collections.Generic;

namespace Starts2000.EFCoreDbFirst
{
    public partial class Efmigrationshistory
    {
        public string MigrationId { get; set; }
        public string ProductVersion { get; set; }
    }
}
