﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microliu.Auth.Domain
{
   public class CreatePositionModel
    {
        public string Name { get; set; }

        public int IsEnable { get; set; }

        public int Sort { get; set; }
    }
}
