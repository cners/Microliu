﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microliu.Auth.Domain.ViewModels
{
    public class SearchPositionModel : BaseByPageQueryModel
    {
        public string Name { get; set; }

    }
}
