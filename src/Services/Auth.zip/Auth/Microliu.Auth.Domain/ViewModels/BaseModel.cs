﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microliu.Auth.Domain
{
    public class BaseModel
    {
    }
}
