﻿using Microliu.Auth.Domain.Entities;

namespace Microliu.Auth.Domain
{
    public interface IUserPositionRepository:IBaseRepository<UserPosition>
    {

    }
}
