﻿namespace Microliu.Auth.Infrastructure
{
    public enum DbType
    {
        Oracle = 1,
        MySQL = 2,
        SQLServer = 4
    }
}
