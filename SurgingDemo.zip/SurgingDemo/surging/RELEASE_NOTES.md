####  0.6.5 May 1 2018
- Add Strategy FallBack
- Fixed bug with rabbitmq Configuration
- Add NLog component
- Fix socket resource exhaustion bug
- Add RpcContext pass parameters

#### Surging.Core.Caching 0.6.3 March 29 2018
- Add Distributed Cache Profile Synchronization Updates 

#### surging 0.6.3 March 29 2018
- Add Distributed Cache Profile Synchronization Updates 
- Add Load Balancing FairPolling Algorithm  
- Add configuration file to define running parameters

#### Surging.Core.Zookeeper 0.5.1 January 17 2017
- Fix problems registered on different servers based on zookeeper and consul

#### Surging.Core.Consul 0.5.1 January 17 2017
- Fix If consul crash, the service runs as usual
- Fix problems registered on different servers based on zookeeper and consul

#### surging 0.5.1 January 17 2017
- Fixed concurrency block
- Add UseProxy
- Fix getservice create proxy remote calls 
- Interfaces that do not implement domain services are not registered
- Fixed a problem with non-proxy calls that enabled cache crashes

#### Surging.Core.Log4net 0.4.8 December 17 2017
- Add logs based on log4net

#### Surging.Core.Zookeeper 0.4.9 December 16 2017
- Fixed using zookeeper registry did not register fault tolerance rules

#### 0.4.8 December 10 2017
- First public release
