﻿define(function (require, exports, module) {
    window.debug = false;
    module.exports = {
        GET_ADDRESS: "/ServiceManage/GetAddress",
        EDIT_SERVICETOKEN:"/AuthenticationManage/EditServiceToken"
    }
});