﻿namespace Surging.Core.AutoMapper
{
    public interface IAutoMapperBootstrap
    {
        void Initialize();
    }
}
