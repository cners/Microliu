﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Surging.Core.ApiGateWay.Configurations
{
   public  enum RegisterProvider
    {
        Consul,
        Zookeeper,
    }
}
