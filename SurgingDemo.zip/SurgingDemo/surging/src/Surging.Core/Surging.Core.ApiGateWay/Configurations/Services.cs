﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Surging.Core.ApiGateWay.Configurations
{
   public class Services
    {
        public  List<ServiceAggregation> serviceAggregation { get; set; }
        public string UrlMapping { get; set; }
    }
}
