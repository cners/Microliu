﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Surging.Core.ApiGateWay.Aggregation
{
   public enum ServicePartType
    {
        None,
        Main,
        Section
    }
}
