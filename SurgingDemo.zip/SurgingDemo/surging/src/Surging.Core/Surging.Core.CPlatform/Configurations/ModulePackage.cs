﻿namespace Surging.Core.CPlatform.Configurations
{
    public class ModulePackage
    {
        public string TypeName { get; set; }
        public string Using { get; set; }
    }
}
