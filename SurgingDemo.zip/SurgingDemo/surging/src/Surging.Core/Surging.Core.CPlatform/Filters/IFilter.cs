﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Surging.Core.CPlatform.Filters
{
   public interface IFilter
    {

        bool AllowMultiple { get; }  
    }
}
