﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Surging.Core.CPlatform.Filters.Implementation
{
    public enum AuthorizationType
    {
        JWT,
        AppSecret
    }
}
