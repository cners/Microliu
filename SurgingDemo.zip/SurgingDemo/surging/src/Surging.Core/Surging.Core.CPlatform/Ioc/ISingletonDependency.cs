﻿
namespace Surging.Core.CPlatform.Ioc
{
    public interface ISingletonDependency
    {
    }
}
