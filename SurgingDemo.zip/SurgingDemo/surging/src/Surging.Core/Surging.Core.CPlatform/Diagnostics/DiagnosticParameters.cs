﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Surging.Core.CPlatform.Diagnostics
{
   public  class DiagnosticParameters
    {
        public const string PREFIX = "Surging.Core.";

        public const string DiagnosticListenerName = "SurgingDiagnosticListener";
    }
}
