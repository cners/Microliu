﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Surging.Core.CPlatform
{
   public class RequestData 
    {
        public string Payload { get; set; }
    }
}
