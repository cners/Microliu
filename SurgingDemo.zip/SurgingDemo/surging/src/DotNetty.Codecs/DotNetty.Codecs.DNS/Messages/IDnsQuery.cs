﻿
namespace DotNetty.Codecs.DNS.Messages
{
    public interface IDnsQuery : IDnsMessage
    {

    }
}
