﻿namespace DotNetty.Codecs.DNS
{
    public enum DnsSection
    {
        QUESTION,
        ANSWER,
        AUTHORITY,
        ADDITIONAL
    }
}
