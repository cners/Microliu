﻿namespace DotNetty.Codecs.DNS.Records
{
    public interface IDnsQuestion : IDnsRecord
    {
    }
}
